# Fusion Programming Language Specification v2

Description: A modern programming language combining the performance of C, structure of Java, simplicity of Python, and readability of VB.NET. Designed for game development, automation, and systems programming.

**Fusion is a combination of various programming languages unified into one cohesive language.**

Note: In syntax examples, `{= defaultValue}` indicates optional default values. The curly braces are notation only, not actual syntax.

---

## Language Philosophy

Description: Core principles guiding Fusion's design decisions.

* Performance First: Compiled to native code with optional JIT
     * C-style memory control when needed
     * Automatic memory management by default
     * Zero-cost abstractions

* Readable and Expressive: Natural language constructs
     * VB.NET-style keyword readability
     * Python-style indentation significance
     * Clear intent over brevity

* Type Safety with Flexibility: Strong typing with inference
     * Java-style static typing
     * Python-style duck typing option
     * Gradual typing support

* Modern Features: Built for today's development
     * First-class functions
     * Pattern matching
     * Async/await native support
     * Null safety by default

---

## Syntax Overview

Description: Core syntax elements borrowed from each parent language.

* From Python: Indentation-based blocks, simple syntax
* From Java: Type annotations, interface contracts
* From C: Pointer operations, memory control (optional)
* From VB.NET: Readable keywords, property syntax

---

## Data Types and Variables

Description: Type system combining static typing with clear null safety rules.

---

### Type Categories

Description: Fusion distinguishes between value types and reference types for null safety.

* **Value Types**: Cannot be null, always have a value
     * Primitives: byte, ubyte, short, ushort, int, uint, long, ulong
     * Floating point: float, double, decimal
     * Boolean: bool
     * Character: char
     * Structs: All value-type structs
     * Note: Syntax like `int?` does NOT exist

* **Reference Types**: Can be null, must be checked before use
     * Objects: All class instances
     * String: Special case (class but treated as value type for convenience)

---

### Complete Type Specifications

Description: All built-in types with their properties and capabilities.

Type | Default | Min | Max | Autobox Class | Safe Cast To
---|---|---|---|---|---
byte | 0 | -128 | 127 | Byte | short, int, long, float, double
ubyte | 0 | 0 | 255 | UByte | ushort, uint, ulong, float, double
short | 0 | -32,768 | 32,767 | Short | int, long, float, double
ushort | 0 | 0 | 65,535 | UShort | uint, ulong, float, double
int | 0 | -2,147,483,648 | 2,147,483,647 | Int | long, float, double
uint | 0 | 0 | 4,294,967,295 | UInt | ulong, float, double
long | 0 | -9,223,372,036,854,775,808 | 9,223,372,036,854,775,807 | Long | float, double
ulong | 0 | 0 | 18,446,744,073,709,551,615 | ULong | float, double
float | 0.0f | ±1.5 x 10^-45 | ±3.4 x 10^38 | Float | double
double | 0.0 | ±5.0 x 10^-324 | ±1.7 x 10^308 | Double | decimal
decimal | 0.0 | ±1.0 x 10^-28 | ±7.9 x 10^28 | Decimal | (highest precision)
bool | false | false | true | Boolean | int (0 or 1)
char | '\0' | U+0000 | U+10FFFF | Char | int, string
string | "" | (empty) | (memory limit) | String | (no casting from)

---

### Nullability Rules

Description: Which types can be null and how to check them.

Type Category | Can Be Null? | Check Method | Example
---|---|---|---
Value Types | NO | N/A (always has value) | `int x` is never null
Structs | NO | N/A (always has value) | `Vector3 v` is never null
String | YES | `str?.null` or `str is null` | `if str?.null then handle`
Objects | YES | `obj?.null` or `obj is null` | `if ship?.null then handle`

---

### Variable Declarations

Description: Multiple declaration styles for different scenarios.

* **Type-First Declaration**: No ambiguity
     * Format: `<type> varName = value`
     * Use when: Type clarity important
     * Example: `int count = 10`

```
int count = 10
string name = "Starship"
float speed = 299792.458
Spaceship ship = Spaceship("Enterprise", 100.0)
```

* **Type Inference**: Less verbose
     * Format: `var varName = value`
     * Use when: Type obvious from value
     * Example: `var count = 10`

```
var name = "Starship"
var speed = 299792.458
var position = Vector3(10, 20, 30)
```

* **Declaration Without Initial Value**: Uses default
     * Format: `<type> varName`
     * Uses default value from table above
     * Example: `int count` defaults to 0

```
int count          // 0
string name        // ""
bool flag          // false
float speed        // 0.0f
Spaceship ship     // null (reference type)
```

---

### Constants

Description: Immutable values declared at compile time.

```
const MAX_SPEED: float = 300000.0
const GAME_VERSION = "1.0.0"
const PI: double = 3.14159265359
```

---

### String Implementation

Description: Immutable strings with copy-on-write semantics.

* **Characteristics**
     * Readonly array of chars
     * Stored in string pool (separate from other values)
     * Multiple references share same string in memory
     * Immutable: editing creates new string
     * Old string garbage collected if no references

* **Memory Model**

```
string name = "Enterprise"     // Stored in string pool
string ref = name              // Both reference same "Enterprise"
ref = "Modified"               // New string created, name unchanged
// Old "Enterprise" kept in pool (name still references it)
```

* **String Operations**: All return new strings

```
string original = "Hello"
string upper = original.toUpper()      // Returns "HELLO", original unchanged
string sub = original.substring(0, 3)  // Returns "Hel", original unchanged
string concat = original + " World"    // Returns "Hello World", original unchanged
```

---

### Type Casting

Description: Converting between types with safety rules.

* **Implicit Casting**: Widening conversions (safe, no data loss)

```
int x = 10
long y = x              // OK: int to long
float f = x             // OK: int to float
double d = f            // OK: float to double
```

* **Explicit Casting**: Narrowing conversions (may lose data)

```
double d = 3.14159
float f = cast<float>(d)           // OK: loses precision
int i = cast<int>(d)               // OK: becomes 3 (truncates)

long big = 1000000000000
int small = cast<int>(big)         // Runtime error if too big!
```

* **Unsigned/Signed Conversions**

```
uint positive = 100
int signed = cast<int>(positive)   // OK: value fits

int negative = -50
uint unsign = cast<uint>(negative) // Runtime error: cannot convert negative!
```

* **String Conversions**

```
// To string (always works via autoboxing)
int num = 42
string str = num.toString()        // "42"

// From string (may fail)
string text = "123"
int num = int.parse(text)          // 123

string invalid = "abc"
int result = int.tryParse(invalid) // Returns option type (may be none)
```

---

## Functions and Methods

Description: Function definition with return-type-first syntax and flexible parameters.

---

### Function Declaration Syntax

Description: Clear, readable function signatures with type safety.

* **Format**: `<returnType> function name(<type> param {= defaultValue})`
     * Return type comes first (like C/Java)
     * Function keyword for clarity (like VB.NET)
     * Type before parameter name
     * Optional default values with `=`
     * void keyword required (cannot be omitted)

* **Basic Functions**

```
void function printMessage(string msg)
    print(msg)

int function add(int a, int b)
    return a + b

Spaceship function createShip(string name, float speed)
    return Spaceship(name, speed)

bool function isValid(int value)
    return value > 0 and value < 100
```

* **Functions with Default Parameters**

```
int function add(int a = 0, int b = 0)
    return a + b

Spaceship function createShip(string name = "Unnamed", float speed = 100.0, int crew = 50)
    return Spaceship(name, speed, crew)

void function configure(bool debug = false, int logLevel = 1)
    setupLogging(debug, logLevel)
```

---

### Function Block Syntax

Description: Flexible block styles for user preference.

* **No Colon Required**
     * Function declaration ends at parameter list
     * New line automatically starts function body

* **Indentation-Based** (Python-style)

```
int function calculate(int x, int y)
    int result = x + y
    result = result * 2
    return result

void function processShip(Spaceship ship)
    ship.start()
    ship.move(forward, speed)
    ship.stop()
```

* **With Braces** (C/Java-style) - Optional syntax sugar

```
// Style 1: Braces on same line
int function add(int a, int b) {
    int result = a + b
    return result
}

// Style 2: Braces on next line
int function add(int a, int b)
{
    int result = a + b
    return result
}

// When braces used, indentation is ignored
```

---

### Calling Functions

Description: Multiple ways to pass arguments for flexibility.

* **Positional Arguments**: Standard calling

```
int result = add(5, 3)
Spaceship ship = createShip("Enterprise", 200.0, 100)
```

* **Named Arguments**: Explicit parameter names

```
// Out of order is OK
int result = add(b = 5, a = 3)
Spaceship ship = createShip(crew = 100, name = "Voyager", speed = 180.0)

// Mix positional and named (positional must come first)
Spaceship ship = createShip("Discovery", crew = 80, speed = 150.0)
```

* **Using Default Values**

```
// Use all defaults
Spaceship ship1 = createShip()  // name="Unnamed", speed=100.0, crew=50

// Override some defaults
Spaceship ship2 = createShip("Enterprise")  // name="Enterprise", others default

// Override with named parameters
Spaceship ship3 = createShip(crew = 200)  // Only crew changed
```

---

### Lambda Expressions

Description: First-class functions and closures.

```
// Simple lambda
var double = lambda x: x * 2
var add = lambda a, b: a + b

// With type annotations
var multiply: (int, int) -> int = lambda x, y: x * y

// Multi-line lambda
var complexCalc = lambda x, y:
    int temp = x * 2
    int result = temp + y
    return result

// Higher-order functions
List<int> function mapValues(List<int> values, (int) -> int operation)
    return values.map(operation)

// Usage
List<int> doubled = mapValues([1, 2, 3], lambda x: x * 2)
```

---

### Error Handling with Multiple Returns

Description: Go-style multiple return values for explicit error handling.

* **Function with Error Return**

```
Spaceship, Error function loadShip(string filename)
    if not fileExists(filename)
        return null, Error("File not found: {filename}")
    
    Spaceship ship = parseShipFile(filename)
    if ship is null
        return null, Error("Invalid ship data")
    
    return ship  // Success - error is implicitly null
```

* **Calling with Error Capture**

```
Spaceship ship, Error err = loadShip("ship.dat")

// Check error first
if err
    print("Error loading ship: {err.message}")
    return

// Safe to use ship (no error occurred)
ship.start()
```

* **Calling Without Error Capture** (Bubble up)

```
// Error bubbles up to caller if it occurs
Spaceship ship = loadShip("ship.dat")
ship.start()
```

* **Error Object**

```
class Error
    string message
    int code
    string stackTrace
    
    constructor(string msg)
        this.message = msg
        this.code = 0
        this.stackTrace = captureStackTrace()
```

* **Error Chaining**

```
Spaceship, Error function loadAndValidateShip(string filename)
    Spaceship ship, Error err = loadShip(filename)
    if err
        return null, err
    
    bool valid, Error err2 = validateShip(ship)
    if err2
        return null, err2
    
    return ship
```

---

## Classes and Objects

Description: Object-oriented programming with modern features and clear syntax.

---

### Class Definition

Description: Java-style structure with Python simplicity.

```
class Spaceship
    // Properties - auto-implementation
    property Name: string { get; private set; }
    property Speed: float { get; set; }
    property Position: Vector3 { get; private set; }
    
    // Constants - automatically static, can be private/public
    public const MAX_SPEED: float = 1000.0
    private const DEFAULT_FUEL: float = 100.0
    
    // Static fields - belong to class, not instance
    private static int shipCount = 0
    public static int TotalShips
        get
            return shipCount
    
    // Private fields - instance-specific
    private float fuelLevel
    private bool isEngineActive
    
    // Constructor - explicit keyword, no return type
    constructor(string name, float initialSpeed)
        this.Name = name
        this.Speed = initialSpeed
        this.Position = Vector3(0, 0, 0)
        this.fuelLevel = DEFAULT_FUEL
        this.isEngineActive = false
        shipCount += 1  // Increment static counter
    
    // Instance methods - return type first
    void function start()
        if fuelLevel > 0
            isEngineActive = true
            print("Engine started: {Name}")
    
    void function move(Vector3 direction, float deltaTime)
        if isEngineActive and fuelLevel > 0
            Position = Position + (direction * Speed * deltaTime)
            fuelLevel -= 0.1 * deltaTime
    
    // Static methods - belong to class itself
    public static Spaceship function createDefault()
        return Spaceship("Default Ship", 100.0)
    
    private static void function resetShipCount()
        shipCount = 0
    
    // Computed property
    property IsOperational: bool
        get
            return isEngineActive and fuelLevel > 0

// Using static members
Spaceship ship1 = Spaceship("Enterprise", 200.0)
Spaceship ship2 = Spaceship.createDefault()  // Call static method
int total = Spaceship.TotalShips             // Access static property
float maxSpeed = Spaceship.MAX_SPEED         // Access const (automatically static)
```

---

### Static vs Instance Members

Description: Understanding class-level vs object-level members.

**Static Members**

* Belong to the class itself, not instances
* Shared across all instances
* Access via class name: `ClassName.staticMember`
* Cannot access instance members (no `this`)
* Use for: Factory methods, counters, utilities, configuration

**Instance Members**

* Belong to each object instance
* Each instance has its own copy
* Access via object: `objectName.instanceMember`
* Can access both static and instance members
* Use for: Object state and behavior

**Constants (const)**

* Automatically static (belong to class)
* Immutable after initialization
* Can be public or private
* Access via class name: `ClassName.CONSTANT_NAME`
* Use for: Configuration values, mathematical constants

```
class MathUtils
    // Constants - automatically static
    public const PI: double = 3.14159265359
    public const E: double = 2.71828182846
    
    // Static method - utility function
    public static float function degreesToRadians(float degrees)
        return degrees * (PI / 180.0)
    
    // Static method - factory
    public static MathUtils function getInstance()
        return MathUtils()

// Usage
float radians = MathUtils.degreesToRadians(90.0)
double pi = MathUtils.PI
```

---

### Properties

Description: VB.NET-inspired properties with enhanced features.

* **Simple Auto-Property**

```
class Spaceship
    property Name: string { get; set; }
    property Speed: float { get; set; }
    property Health: float { get; private set; }  // Read-only outside class
```

* **Property with Validation**

```
class Spaceship
    private float _speed
    
    property Speed: float
        get
            return _speed
        set
            if value < 0
                _speed = 0
            else
                _speed = value
```

* **Computed Property**

```
class Spaceship
    float fuel
    float maxFuel
    
    property FuelPercent: float
        get
            return (fuel / maxFuel) * 100.0
```

* **Array Property with Indexed Access**

```
class Inventory
    private List<Item> items
    
    // Normal property - returns entire list
    property Items: List<Item>
        get
            return items
        set
            items = value
    
    // Indexed property - access specific item
    property Items[int index]: Item
        get
            return items[index]
        set
            items[index] = value

// Usage
Inventory inv = Inventory()
List<Item> allItems = inv.Items      // Get entire list
Item firstItem = inv.Items[0]        // Get by index
inv.Items[1] = newItem               // Set by index
```

* **Indexed-Only Property** (No array replacement)

```
class Inventory
    private List<Item> items
    
    // Only indexed access - cannot replace entire list
    property Items[int index]: Item
        get
            return items[index]
        set
            items[index] = value
    
    // Helper methods for array management
    void function addItem(Item item)
        items.add(item)
    
    property ItemCount: int
        get
            return items.length

// Usage
Inventory inv = Inventory()
// List<Item> all = inv.Items  // ERROR: Cannot access entire list
Item item = inv.Items[0]       // OK: Access by index
inv.addItem(newItem)           // OK: Use method
```

* **Multi-Dimensional Indexer**

```
class Grid
    private int[10][10] cells
    
    property Cell[int x, int y]: int
        get
            return cells[x][y]
        set
            cells[x][y] = value

// Usage
Grid grid = Grid()
grid.Cell[5, 3] = 42
int value = grid.Cell[5, 3]
```

---

### Inheritance

Description: Single inheritance with interface support.

```
class Warship extends Spaceship
    property WeaponPower: int { get; set; }
    
    constructor(string name, float speed, int weaponPower)
        super(name, speed)  // Call parent constructor
        this.WeaponPower = weaponPower
    
    void function fire(Spaceship target)
        print("{Name} fires at {target.Name}!")
        target.takeDamage(WeaponPower)
```

---

### Static Methods and Constants

Description: Class-level members and constants that belong to the class itself.

* **Static Methods**: Belong to class, not instance

```
class MathUtils
    // Static method - no instance needed
    public static int function max(int a, int b)
        if a > b
            return a
        else
            return b
    
    public static float function average(float... numbers)
        float sum = 0
        for num in numbers
            sum += num
        end loop
        return sum / numbers.length
    
    // Private static - only accessible within class
    private static void function internalHelper()
        // Implementation

// Usage - call on class, not instance
int result = MathUtils.max(10, 20)
float avg = MathUtils.average(1.5, 2.5, 3.5)
```

* **Static Fields**: Shared across all instances

```
class Counter
    private static int count = 0
    
    constructor()
        Counter.count += 1  // Increment shared counter
    
    public static int function getCount()
        return count

// All instances share same count
Counter c1 = Counter()  // count = 1
Counter c2 = Counter()  // count = 2
int total = Counter.getCount()  // Returns 2
```

* **Constants**: Automatically static

```
class Config
    // const is implicitly static
    public const string VERSION = "1.0.0"
    public const int MAX_CONNECTIONS = 100
    private const float PI = 3.14159
    
    // No need to write "static const" - it's redundant

// Usage
string version = Config.VERSION
int maxConn = Config.MAX_CONNECTIONS
```

**Rules**:
* Static methods can only access other static members
* Instance methods can access both static and instance members
* Static members are shared across all instances
* Constants are automatically static (cannot create instance constants)
* Static members can be public or private
* Access static members via `ClassName.memberName`

---

## Interfaces and Contracts

Description: Java-style interfaces with modern enhancements.

---

### Interface Definition

Description: Contract specification for implementation.

```
interface IMovable
    void function move(Vector3 direction, float deltaTime)
    void function stop()
    property Speed: float { get; }

interface IDamageable
    property Health: float { get; set; }
    void function takeDamage(float amount)
    
    // Default implementation (optional)
    bool function isAlive()
        return Health > 0
```

---

### Implementing Interfaces

Description: Classes can implement multiple interfaces.

```
class GameObject implements IMovable, IDamageable
    property Speed: float { get; set; }
    property Health: float { get; set; }
    
    constructor()
        Speed = 50.0
        Health = 100.0
    
    void function move(Vector3 direction, float deltaTime)
        // Implementation
        position = position + (direction * Speed * deltaTime)
    
    void function stop()
        Speed = 0
    
    void function takeDamage(float amount)
        Health -= amount
        if Health < 0
            Health = 0
```

---

## Structures and Value Types

Description: Lightweight value types for performance-critical code.

---

### Struct Restrictions

Description: Structs are pure value containers, not complex objects.

* **Allowed Types in Structs**
     * Primitives: byte, ubyte, short, ushort, int, uint, long, ulong
     * Floating: float, double, decimal
     * Boolean: bool
     * Character: char
     * String: string (stored separately in string pool)
     * Fixed arrays: int[10], float[5] (size must be specified)

* **NOT Allowed in Structs**
     * Object references
     * Dynamic collections (List, Dictionary, Set)
     * Other complex types

* **Reasoning**: If you need objects or complex behavior, use a class instead

---

### Structure Definition

Description: Stack-allocated value types with value semantics.

```
// Valid struct - value types only
struct Vector3
    float x
    float y
    float z
    
    // Constructor
    constructor(float x, float y, float z)
        this.x = x
        this.y = y
        this.z = z
    
    // Operator overloading
    Vector3 operator +(Vector3 other)
        return Vector3(x + other.x, y + other.y, z + other.z)
    
    Vector3 operator *(float scalar)
        return Vector3(x * scalar, y * scalar, z * scalar)
    
    float function magnitude()
        return sqrt(x * x + y * y + z * z)

// Valid struct with fixed array
struct PlayerData
    int[3] position      // Fixed-size array
    float health
    int score
    string name          // String stored separately
    bool isAlive

// Invalid struct - would cause compile error
/*
struct InvalidExample
    List<Item> inventory     // ERROR: dynamic collection not allowed
    Weapon weapon            // ERROR: object reference not allowed
*/
```

---

### Value Semantics

Description: Structs are copied, not referenced.

```
// Usage - value semantics
Vector3 pos1 = Vector3(10, 20, 30)
Vector3 pos2 = pos1           // Copied, not referenced
pos2.x = 50                   // pos1.x is still 10

// Struct parameters are copied
void function modifyVector(Vector3 v)
    v.x = 100  // Modifies copy, not original

Vector3 original = Vector3(1, 2, 3)
modifyVector(original)
// original.x is still 1
```

---

## Enumerations

Description: Named constant values for type-safe selections.

---

### Enum Syntax

Description: Three syntax options based on user preference and context.

* **Option 1: Braces** (C/Java style)

```
Enum Planets {
    MERCURY,
    VENUS,
    EARTH,
    MARS,
    JUPITER,
    SATURN,
    URANUS,
    NEPTUNE
}
```

* **Option 2: Indentation** (Python style)

```
Enum Planets
    MERCURY
    VENUS
    EARTH
    MARS
    JUPITER
    SATURN
    URANUS
    NEPTUNE
```

* **Option 3: Single-Line** (Compact)

```
Enum Planets: MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
```

**Usage Guidelines**:
* Single-line: For simple lists (< 10 items or < 80 characters)
* Indentation or braces: For longer lists or when items have values

---

### Enum with Values

Description: Custom integer values for enum constants.

```
// With braces
Enum StatusCode {
    OK = 200,
    CREATED = 201,
    BAD_REQUEST = 400,
    NOT_FOUND = 404,
    SERVER_ERROR = 500
}

// With indentation
Enum StatusCode
    OK = 200
    CREATED = 201
    BAD_REQUEST = 400
    NOT_FOUND = 404
    SERVER_ERROR = 500

// Default values (0, 1, 2, ...)
Enum Priority {
    LOW,      // 0
    MEDIUM,   // 1
    HIGH,     // 2
    CRITICAL  // 3
}
```

---

### Using Enums

Description: Type-safe constant selection.

```
// Declaration
Planets planet = Planets.MARS
StatusCode status = StatusCode.OK

// Comparison
if status == StatusCode.OK
    print("Success!")

if planet == Planets.EARTH
    print("Home planet")

// Match statement
match status
    case StatusCode.OK:
        print("Request successful")
    case StatusCode.NOT_FOUND:
        print("Resource not found")
    case StatusCode.SERVER_ERROR:
        print("Server error occurred")

// Get integer value
int code = status.toInt()  // 200

// Iteration
for planet in Planets.values()
    print(planet.toString())
end loop
```

---

### Enum Properties

Description: Built-in methods and properties.

```
Enum Direction: NORTH, SOUTH, EAST, WEST

Direction dir = Direction.NORTH

// Properties
string name = dir.name          // "NORTH"
int value = dir.value           // 0
int ordinal = dir.ordinal       // 0 (position in enum)

// Methods
string str = dir.toString()     // "NORTH"
Direction next = dir.next()     // SOUTH
Direction prev = dir.previous() // WEST (wraps around)

// Static methods
List<Direction> all = Direction.values()
Direction d = Direction.fromString("NORTH")
Direction d2 = Direction.fromValue(0)
```

---

## Control Flow

Description: Natural language constructs for program flow with safety features.

---

### Conditionals

Description: Clear and readable branching with multiple comparison operators.

* **Comparison Operators**

Operator | Meaning | Example
---|---|---
`==` | Equal to | `if x == 10`
`!=` | Not equal to | `if x != 0`
`<>` | Not equal to (alternative) | `if x <> 0`
`<` | Less than | `if x < 10`
`>` | Greater than | `if x > 5`
`<=` | Less than or equal | `if x <= 10`
`>=` | Greater than or equal | `if x >= 5`

```
// If statements with comparisons
if ship.fuelLevel > 50
    ship.engageWarpDrive()
elif ship.fuelLevel <> 0
    ship.startEngine()
else
    print("No fuel!")

// Using <> operator
int x = 10
int y = 20

if x <> y
    print("Values are not equal")

// Both work the same
if x != y
    print("Values are not equal")

// Pattern matching
match ship.type
    case ShipType.Fighter:
        ship.activateWeapons()
    case ShipType.Cargo:
        ship.openCargoBay()
    case ShipType.Explorer:
        ship.deploySensors()
    else:
        print("Unknown ship type")
```

---

### Loops with Safety Checks

Description: Explicit loop termination with multiple safety mechanisms.

* **Basic Loop Syntax**

```
// While loop
while condition
    // body
end loop

// For loop with range function
for i in range(0, 10)
    print("Count: {i}")
end loop

// For loop with ... range operator
for i in 1...10
    print("Number: {i}")  // 1, 2, 3, ..., 10
end loop

// Range with step
for i in 0...100...10
    print(i)  // 0, 10, 20, 30, ..., 100
end loop

// For-each loop
for ship in fleet
    ship.update(deltaTime)
end loop
```

* **The `...` Operator**

Description: Multi-purpose operator for ranges, spreads, and variadic arguments.

**Use 1: Range in Loops**
```
// Simple range
for i in 1...100
    processItem(i)
end loop

// Range with step
for x in 0...360...45
    drawAngle(x)  // 0, 45, 90, 135, 180, 225, 270, 315, 360
end loop

// Create array from range
int[] numbers = [1...10]  // [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
```

**Use 2: Variadic Functions**
```
int function sum(int... numbers)
    int total = 0
    for num in numbers
        total += num
    end loop
    return total

// Call with any number of arguments
int result = sum(1, 2, 3, 4, 5)  // 15
int result2 = sum(10, 20)         // 30
```

**Use 3: Array Spread**
```
int[] arr1 = [1, 2, 3]
int[] arr2 = [4, 5, 6]

// Spread into new array
int[] combined = [...arr1, ...arr2]  // [1, 2, 3, 4, 5, 6]

// Spread in function call
int total = sum(...combined)
```

**Use 4: Rest Parameters**
```
void function logMessage(string level, string... messages)
    for msg in messages
        print("[{level}] {msg}")
    end loop

// Usage
logMessage("INFO", "Starting", "Loading", "Complete")
```

* **Automatic Compiler Protections**

Description: Compiler automatically adds safety checks to loops.

```
// User writes:
for i in range(1000)
    processData(i)
end loop

// Compiler automatically adds (invisible to user):
// - Infinite loop protection (default 1,000,000 iterations)
// - Thread interrupt checking (for graceful shutdown)
// - System resource monitoring (RAM/CPU usage)
```

**Configuration**:
* Default iteration limit: Based on system resources
* Project setting: `fusion.config.max_iterations = 10000000`
* Per-loop override: `#[max_iterations(100000)]`
* Disable protection: `#[no_loop_protection]` (use with caution)

**System Resource Adaptation**:
* Automatically adjusts limits based on available RAM
* Monitors CPU usage during loops
* Responds to OS shutdown signals
* Graceful degradation under resource pressure

```
// Disable automatic protection (advanced use only)
#[no_loop_protection]
while serverRunning
    handleRequest()
end loop
```

* **Loop with Manual Exit Condition**

```
int count = 0
while ship.isActive
    ship.update(deltaTime)
    count += 1
    
    // Manual break
    if count > 1000
        break
        
end loop with
    check
        if not ship.isValid()
            print("Warning: Invalid state")
```

* **Loop with Periodic Check** (Every N iterations)

```
for i in range(100000)
    processData(i)
    
end loop with {10}  // Check every 10th iteration
    check
        if systemOverloaded()
            print("System overload at iteration {i}")
            exit loop
```

* **Loop with Iteration Limit** (Infinite loop prevention)

```
while processing
    doWork()
    
end loop with {100000}  // Exit if exceeds 100,000 iterations
    check
        if iteration >= 100000
            print("Loop limit reached")
            exit loop
```

* **Loop with Thread Interrupt Handling**

```
for item in hugeCollection
    processItem(item)
    
end loop with
    check interrupt(signal, data)
        if signal == InterruptSignal.Shutdown
            print("Received shutdown signal")
            cleanup()
            exit loop
        
        if signal == InterruptSignal.Pause
            waitForResume()
            continue loop
```

* **Complete Loop Example** (All check types)

```
int count = 0
bool processing = true

while processing
    data = fetchData()
    processData(data)
    count += 1
    
    if count >= maxCount
        break

end loop with {50}  // Periodic check every 50 iterations
    
    check
        if not isHealthy()
            print("System unhealthy")
            exit loop
    
    check
        if count >= 10000
            print("Maximum iterations reached")
            exit loop
    
    check interrupt(signal, data)
        if signal == InterruptSignal.Stop
            print("Stop signal received")
            processing = false
            exit loop
```

* **Simple Loop** (Automatic safety)

```
// Most loops don't need explicit checks
for i in range(100)
    doWork(i)
end loop

// System automatically provides:
// - Infinite loop protection (default 1M iterations)
//   * Configurable based on system resources (RAM/CPU/disk space)
//   * Compiler settings can adjust based on available resources
//   * User settings can override for specific needs
//   * Protects PC from hanging or crashes
// - Thread interrupt checking
//   * Handles system shutdown gracefully
//   * Responds to user interrupts (Ctrl+C)
//   * No manual handling needed
//   * Cooperative multitasking automatic
```

**Note**: The compiler/runtime automatically adds these protections even if user doesn't specify them. This prevents common programming errors and system hangs without requiring explicit code from the developer.

---

### Loop Labels

Description: Named loops for nested break/continue.

```
outer: for x in range(10)
    for y in range(10)
        if grid[x][y] == target
            print("Found at ({x}, {y})")
            break outer
    end loop
end loop
```

---

## Null Handling

Description: Type-based null safety preventing null reference errors.

---

### Core Principles

* **Value types**: Cannot be null, always have a value
* **Reference types**: Can be null, must be checked before use
* **Compiler enforcement**: Strict mode forces null checks

---

### Null Checking Methods

Description: Multiple ways to check and handle null values.

* **Check if Null**

```
Spaceship ship = getShip()

// Method 1: Using ?.null
if ship?.null
    print("Ship is null")
    return

// Method 2: Using is null
if ship is null
    print("Ship is null")
    return

// Safe to use ship here
ship.start()
```

* **Safe Navigation Operator**

```
// Returns none if ship is null, otherwise returns the property
string name = ship?.name

// Chain safely
string captainName = ship?.captain?.name

// With default value
string name = ship?.name ?? "Unknown"
```

* **String Special Case**

```
string text = getString()

// Returns 0 if null or empty
int len = text?.length

// Safe operations
string upper = text?.toUpper() ?? ""
```

---

### Strict Mode

Description: Compiler enforces null checks for function parameters.

```
// With strict mode enabled, this generates automatic null check
void function processShip(Spaceship ship)
    // Compiler adds: if ship?.null then error("Ship cannot be null")
    ship.start()
    ship.move(forward, speed)

// Manual null handling
void function processShip(Spaceship ship)
    if ship?.null
        print("Cannot process null ship")
        return
    
    ship.start()
```

---

## Autoboxing

Description: Automatic primitive-to-object conversion for method calls.

---

### How It Works

* Primitives automatically become objects when calling methods
* Compiler handles conversion transparently
* No manual boxing required
* Performance optimized

---

### Using Autoboxing

Description: Call methods on primitives seamlessly.

* **Number Methods**

```
int num = 42
string str = num.toString()           // "42"
string hex = num.toHexString()        // "2A"
string binary = num.toBinaryString()  // "101010"

float pi = 3.14159
float rounded = pi.round(2)           // 3.14
int truncated = pi.floor()            // 3
```

* **String Methods**

```
string text = "hello world"
string upper = text.toUpper()         // "HELLO WORLD"
string sub = text.substring(0, 5)     // "hello"
int length = text.length              // 11
bool contains = text.contains("world") // true
```

* **Array Methods**

```
int[] numbers = [1, 2, 3, 4, 5]
int len = numbers.length              // 5
int sum = numbers.sum()               // 15
int max = numbers.max()               // 5
int[] doubled = numbers.map(lambda x: x * 2)
```

* **Array Safe Navigation with `?.`**

```
int[]? nullableArray = getArray()

// Safe array access
int? first = nullableArray?[0]        // Returns null if array is null
int len = nullableArray?.length ?? 0   // Returns 0 if null

// Safe method calls
int? sum = nullableArray?.sum()        // Returns null if array is null
int[]? doubled = nullableArray?.map(lambda x: x * 2)

// Chaining safe operations
int[]? filtered = nullableArray?.filter(lambda x: x > 10)
int? max = filtered?.max()

// Must handle null manually
if nullableArray?.null
    print("Array is null!")
else
    for item in nullableArray
        process(item)
    end loop
```

**Note on ?. Operator**

* The `?.` operator is optional for objects and arrays
* User can choose to use it for safety
* If used, must manually handle the none/null result afterwards
* Without it, accessing null reference causes runtime error (or compile error in strict mode)

```
// With ?. - manual handling required
Spaceship ship = getShip()
string name = ship?.name  // Returns none if ship is null
if name is null
    print("Ship or name is null")

// Without ?. - runtime/compile error if null
Spaceship ship = getShip()
string name = ship.name   // Error if ship is null!
```

---

### Autobox Classes

Description: Each primitive type has corresponding object class.

Primitive | Autobox Class | Example Methods
---|---|---
int | Int | toString(), toHexString(), abs()
uint | UInt | toString(), toHexString()
long | Long | toString(), abs()
float | Float | toString(), round(), floor(), ceil()
double | Double | toString(), round(), floor(), ceil()
bool | Boolean | toString(), not()
char | Char | toString(), toUpper(), toLower(), isDigit()
byte | Byte | toString(), toHexString()

---

## Memory Management

Description: Three-tier memory management strategy for different use cases.

---

### Tier 1: Automatic Garbage Collection (Default)

Description: Automatic memory management for most use cases.

* No manual memory management needed
* Like Java, Python, C#
* Suitable for 95% of applications
* Simplest for developers

```
// Automatic cleanup
Spaceship ship = Spaceship("Enterprise", 100.0)
// Automatically garbage collected when no longer referenced
```

---

### Tier 2: Smart Pointers (Performance Mode)

Description: Explicit lifetime control without garbage collection pauses.

* **Unique Pointer**: Single ownership
     * Only one owner at a time
     * Automatically deleted when owner goes out of scope
     * Cannot be copied, only moved
     * Zero overhead
     * Use for: temporary objects, factory returns, single-owner scenarios

```
// Creating unique pointer
Unique<Spaceship> ship = Unique.create<Spaceship>("Enterprise", 100.0)

// Use like normal object
ship.start()
ship.move(direction, speed)

// Transfer ownership (move)
Unique<Spaceship> newOwner = ship.move()  // ship is now null

// Automatic cleanup when newOwner goes out of scope
```

* **Shared Pointer**: Reference counting
     * Multiple owners allowed
     * Keeps count of references
     * Deleted when count reaches zero
     * Can be copied
     * Small overhead (reference count storage)
     * Use for: shared resources (textures, sounds, configs)

```
// Creating shared pointer
Shared<Texture> texture = Shared.create<Texture>("ship.png")
print("Ref count: {texture.refCount()}")  // 1

// Make copies (reference count increases)
Shared<Texture> copy1 = texture  // Ref count: 2
Shared<Texture> copy2 = texture  // Ref count: 3

// All copies deleted when ref count reaches 0
```

* **Weak Pointer**: Non-owning reference
     * Doesn't increase reference count
     * Must check if object still exists before use
     * Breaks circular references
     * Use for: observer pattern, parent-child relationships
     * **WARNING**: Discouraged in most code
     * **STRICT MODE**: Causes compilation error
     * Only use when absolutely necessary to break circular references

```
// Breaking circular reference
class Parent
    Shared<Child> child

class Child
    Weak<Parent> parent  // Weak reference prevents memory leak

// Using weak pointer
Shared<Parent>? parentRef = child.parent.lock()
if parentRef?.null
    print("Parent no longer exists")
else
    parentRef.doSomething()

// In strict mode, this would cause a compile error
// Prefer redesigning to avoid circular references
```

---

### Tier 3: Raw Pointers (Unsafe Mode)

Description: Manual memory management for embedded systems.

* Only for embedded systems or FFI (Foreign Function Interface)
* Requires `unsafe` blocks
* Manual allocation and deallocation
* Compiler warnings and restrictions

```
unsafe
    Spaceship* rawPtr = allocate<Spaceship>(1)
    rawPtr.initialize("Manual", 200.0)
    // ... use pointer
    deallocate(rawPtr)
```

---

### Memory Strategy Summary

Mode | Use Case | Complexity | Performance
---|---|---|---
Automatic GC | General applications | Low | Good
Smart Pointers | Performance-critical | Medium | Excellent
Raw Pointers | Embedded/FFI only | High | Maximum

**Recommendation**: Start with automatic GC, use smart pointers only when profiling shows need

---

## Threading and Concurrency Model

Description: Hybrid concurrency model supporting both message passing and shared memory.

Note: This is a high-level overview. Full threading specification will be in a separate detailed document.

---

### Threading Hierarchy

Description: Layers of concurrent execution units.

* **System**: Operating system managing all processes
* **Process**: Isolated execution with own memory space
* **Thread**: Lightweight unit within process, shares memory
* **Task/Goroutine**: User-space thread, very lightweight
* **Channel**: Communication queue between threads

Extended Hierarchy: System → Process → Thread Pool → Thread → Task/Job → Channel/Queue

---

### Two Concurrency Approaches

Description: Fusion supports both paradigms for maximum flexibility.

---

#### Approach 1: Message Passing (Recommended)

Description: Share memory by communicating (Go-style).

* **Philosophy**: Don't share memory, send messages instead
* **Benefits**: No locks needed, no race conditions, clearer ownership
* **Use**: Default approach for most concurrent code

**How It Works**

* Threads don't share variables directly
* Data sent through channels
* Only one thread owns data at a time
* Ownership transfers through channel

**Analogy**: Sending emails vs writing on shared whiteboard

```
// Create channel
Channel<Task> taskQueue = Channel.create<Task>()

// Producer thread
void function producer()
    for i in range(100)
        Task task = createTask(i)
        taskQueue.send(task)  // Send to channel
    end loop

// Consumer thread
void function consumer()
    while true
        Task task = taskQueue.receive()  // Receive from channel
        processTask(task)
    end loop
```

---

#### Approach 2: Shared Memory (Traditional)

Description: Communicate by sharing memory (requires locks).

* **Philosophy**: Multiple threads access same variables
* **Requirement**: Must use locks/mutexes for synchronization
* **Benefits**: Sometimes more natural for certain problems
* **Use**: When message passing doesn't fit

**How It Works**

* Threads access shared variables
* Mutex locks prevent race conditions
* Must remember to lock/unlock

```
// Shared counter with mutex
class Counter
    private int count
    private Mutex mutex
    
    void function increment()
        mutex.lock()
        count += 1
        mutex.unlock()
    
    int function getCount()
        mutex.lock()
        int value = count
        mutex.unlock()
        return value
```

---

### "Share Memory by Communicating" Explained

Description: Understanding Go's concurrency philosophy.

**Traditional Approach** (Shared Memory)

* Multiple threads write to same variable
* Use mutex to prevent conflicts
* Easy to forget locks → bugs
* Easy to deadlock

```
// Shared variable approach
int sharedCounter = 0
Mutex lock

// Thread 1
lock.acquire()
sharedCounter += 1
lock.release()

// Thread 2
lock.acquire()
sharedCounter += 1
lock.release()
```

**Go's Approach** (Message Passing)

* Don't share variables
* Send data through channels
* Only one thread "owns" data
* No locks needed

```
// Channel approach
Channel<int> updates = Channel.create<int>()

// Thread 1 sends update
updates.send(1)

// Thread 2 sends update
updates.send(1)

// Counter thread receives all updates
int counter = 0
while true
    int update = updates.receive()
    counter += update
end loop
```

---

### Try-With-Resources Pattern

Description: Automatic resource locking to prevent race conditions and deadlocks.

* **Automatic Locking**: Compiler adds locks automatically
* **No Manual Lock/Unlock**: User doesn't need to manage locks
* **Race Condition Prevention**: Automatic synchronization
* **Deadlock Prevention**: Smart lock ordering by compiler

**How It Works**

* When thread/channel tries to access resource, it's locked automatically
* Resource unlocked when done (scope ends or exception thrown)
* Compiler analyzes code to prevent deadlocks
* User can add custom locks if needed

**File Handling Example**

```
// Automatic locking for file access
using file = openFile("data.txt")
    file.write("Some data")
    file.flush()
// File automatically closed and unlocked

// Multiple threads accessing same file
// Thread 1
using file = openFile("shared.txt")
    file.write("Thread 1 data")
// Unlocked

// Thread 2 (waits for Thread 1 to finish)
using file = openFile("shared.txt")
    file.write("Thread 2 data")
// Unlocked
```

**Object/Variable Locking Example**

```
class Counter
    private int count
    
    // Compiler automatically adds locking
    void function increment()
        using this  // Lock entire object
            count += 1
        // Unlocked
    
    int function getCount()
        using this
            return count

// Multiple threads calling increment() - automatically synchronized
Counter counter = Counter()

// Thread 1
counter.increment()  // Locked during execution

// Thread 2
counter.increment()  // Waits for Thread 1, then executes
```

**Manual Locking (When Needed)**

```
// User can specify custom locking
Mutex customLock = Mutex()

void function criticalSection()
    using customLock
        // Protected code
        sharedVariable += 1
    // Unlocked
```

**Compiler Optimizations**

* Analyzes resource access patterns
* Determines minimal locking needed
* Orders locks to prevent deadlocks
* Adds locks only where necessary for performance

---

### Thread Interrupt Handling

Description: Cooperative multitasking via loop checks.

* Threads can signal other threads to stop/pause
* Checked at `end loop` automatically
* Graceful shutdown possible

```
for item in largeDataset
    processItem(item)
    
end loop with
    check interrupt(signal, data)
        if signal == InterruptSignal.Shutdown
            saveProgress()
            cleanup()
            exit loop
        
        if signal == InterruptSignal.Pause
            waitForResume()
            continue loop
```

---

### Async/Await Pattern

Description: Modern asynchronous programming for I/O operations.

```
// Async function
async Spaceship, Error function downloadShipData(string url)
    Response response = await http.get(url)
    
    if response.statusCode != 200
        return null, Error("HTTP error: {response.statusCode}")
    
    string data = await response.readBody()
    Spaceship ship = parseShipData(data)
    return ship, null

// Calling async function
Spaceship ship, Error err = await downloadShipData("https://api.ships.com/ship/1")
if err
    print("Error: {err.message}")
else
    print("Loaded ship: {ship.Name}")
```

---

### Thread Safety Summary

Strategy | Pros | Cons | Use When
---|---|---|---
Message Passing | Safe, no locks, clear ownership | Learning curve | Default choice
Shared Memory | Familiar, sometimes natural | Needs locks, error-prone | Specific performance needs
Async/Await | Clean syntax, efficient I/O | Not for CPU-bound | I/O operations

**Note**: Full threading specification with thread pools, synchronization primitives, and detailed examples will be in separate document.

---

## Generics and Templates

Description: Type-safe generic programming.

---

### Generic Classes

Description: Parameterized types for reusable code.

```
class Container<T>
    private List<T> items
    
    constructor()
        items = List<T>()
    
    void function add(T item)
        items.append(item)
    
    T function get(int index)
        return items[index]
    
    property Count: int
        get
            return items.length

// Usage
Container<int> intContainer = Container<int>()
intContainer.add(42)

Container<Spaceship> shipContainer = Container<Spaceship>()
shipContainer.add(Spaceship("Alpha", 100.0))
```

---

### Generic Functions

Description: Type-parameterized functions with constraints.

```
// Generic function with constraints
T function findMax<T>(List<T> items) where T implements IComparable<T>
    if items.isEmpty()
        throw Exception("Cannot find max of empty list")
    
    T max = items[0]
    for item in items
        if item.compareTo(max) > 0
            max = item
    end loop
    
    return max

// Usage
List<int> numbers = [1, 5, 3, 9, 2]
int maxNum = findMax<int>(numbers)  // 9
```

---

### Multiple Type Parameters

Description: Functions and classes with multiple generic types.

```
class Dictionary<K, V>
    void function put(K key, V value)
        // Implementation
    
    V function get(K key)
        // Implementation

// Usage
Dictionary<string, int> ages = Dictionary<string, int>()
ages.put("Alice", 30)
int age = ages.get("Alice")
```

---

## Error Handling

Description: Explicit error handling with multiple return values.

---

### Multiple Return Values

Description: Go-style error handling with type safety.

* Functions return both result and error
* Error is null if operation succeeded
* Must check error before using result
* Explicit and visible in function signature

---

### Function with Error Return

```
Spaceship, Error function loadShip(string filename)
    if not fileExists(filename)
        return null, Error("File not found: {filename}")
    
    string data = readFile(filename)
    if data.isEmpty()
        return null, Error("Empty file")
    
    Spaceship ship = parseShipData(data)
    if ship is null
        return null, Error("Invalid ship data")
    
    return ship  // Success - error is implicitly null
```

---

### Calling with Error Capture

```
Spaceship ship, Error err = loadShip("ship.dat")

// Check error first
if err
    print("Error loading ship: {err.message}")
    return

// Safe to use ship here (no error occurred)
ship.start()
ship.move(forward, speed)
```

---

### Calling Without Error Capture

Description: Error bubbles up to caller if it occurs.

```
// Don't capture error - will propagate to caller
Spaceship ship = loadShip("ship.dat")
ship.start()

// If loadShip returns error, it bubbles up
```

---

### Error Chaining

```
Spaceship, Error function loadAndValidateShip(string filename)
    // Load ship
    Spaceship ship, Error err = loadShip(filename)
    if err
        return null, err  // Propagate error
    
    // Validate ship
    bool valid, Error err2 = validateShip(ship)
    if err2
        return null, err2  // Propagate error
    
    // Success
    return ship
```

---

### Error Object

```
class Error
    string message
    int code
    string stackTrace
    
    constructor(string msg)
        this.message = msg
        this.code = 0
        this.stackTrace = captureStackTrace()
    
    constructor(string msg, int code)
        this.message = msg
        this.code = code
        this.stackTrace = captureStackTrace()
```

---

### Traditional Exceptions

Description: Available for unexpected errors when needed.

```
void function riskyOperation()
    try
        Data data = readNetworkData()
        processData(data)
    catch NetworkException as e
        print("Network error: {e.message}")
    catch ParseException as e
        print("Parse error: {e.message}")
    finally
        cleanup()
```

---

### When to Use Each

* **Multiple Returns**: Expected errors (file not found, invalid input, network timeout)
* **Exceptions**: Unexpected errors (out of memory, assertion failures, system errors)

---

## Comments and Code Organization

Description: Code documentation and organizational features.

---

### Single-Line Comments

Description: Two comment styles based on user preference.

* **Double Slash** (Stored as `//` in Fusion)

```
// This is a single-line comment
int count = 10  // End-of-line comment

// Multiple single-line comments
// can be used for longer
// explanations
```

* **Single Quote** (User preference, converted to `//`)

```
' This is a single-line comment
int count = 10  ' End-of-line comment

' Multiple single-line comments
' using single quotes
```

**Note**: Both styles work identically. Fusion internally stores all comments as `//`. User can configure IDE preference.

---

### Multi-Line Comments

Description: Block comments spanning multiple lines.

```
/* 
 * This is a multi-line comment
 * Spanning multiple lines
 * Useful for longer explanations
 */

void function processData(Data data)
    /* Quick inline multi-line comment */
    data.process()

/*
 * Function: calculateDistance
 * Parameters:
 *   - x1, y1: First point
 *   - x2, y2: Second point
 * Returns: Distance between points
 */
float function calculateDistance(float x1, float y1, float x2, float y2)
    float dx = x2 - x1
    float dy = y2 - y1
    return sqrt(dx * dx + dy * dy)
```

---

### Region Blocks

Description: Collapsible code sections for IDE organization.

* **Purpose**: Organize large files into logical sections
* **IDE Support**: Regions can be collapsed/expanded in IDE
* **No Runtime Effect**: Pure organizational feature

```
#Region Initialization Code
void function initialize()
    setupSystem()
    loadConfiguration()
    connectDatabase()

void function setupSystem()
    // System setup code
#End Region

#Region Helper Functions
void function helper1()
    // Helper implementation

void function helper2()
    // Helper implementation

private void function internalHelper()
    // Internal helper
#End Region

#Region Data Structures
class DataCache
    // Cache implementation

struct CacheEntry
    string key
    string value
#End Region
```

**Features**:
* String literal displays in IDE when collapsed
* Can nest regions
* Helps navigate large files
* No effect on compilation
* IDE shows as: `[+] Initialization Code`

---

### Documentation Comments

Description: Special comments for API documentation generation.

```
/**
 * Calculates the distance between two points in 2D space.
 * 
 * @param x1 X coordinate of first point
 * @param y1 Y coordinate of first point
 * @param x2 X coordinate of second point
 * @param y2 Y coordinate of second point
 * @return Distance between the points
 * @example
 *   float dist = calculateDistance(0, 0, 3, 4)  // Returns 5.0
 */
float function calculateDistance(float x1, float y1, float x2, float y2)
    float dx = x2 - x1
    float dy = y2 - y1
    return sqrt(dx * dx + dy * dy)
```

---

## Async and Concurrency

Description: Built-in support for asynchronous programming.

* Async/Await: Modern asynchronous pattern
     * Native language support
     * Task-based model
     * Automatic state machine generation

* Parallel Processing: Multi-threading support
     * Thread-safe collections
     * Atomic operations
     * Lock-free structures

```fusion
// Async function
async function downloadShipData(url: string) -> Result<Spaceship, string>:
    var response = await http.get(url)
    
    if response.statusCode != 200:
        return Result.Error("HTTP error: {response.statusCode}")
    
    var data = await response.readBody()
    var ship = parseShipData(data)
    return Result.Ok(ship)

// Parallel processing
async function updateFleet(fleet: List<Spaceship>, deltaTime: float) -> void:
    var tasks = List<Task>()
    
    for ship in fleet:
        var task = async:
            ship.update(deltaTime)
        tasks.append(task)
    
    await Task.waitAll(tasks)

// Concurrent data structures
var safeQueue = ConcurrentQueue<Task>()
parallel for i in range(1000):
    safeQueue.enqueue(createTask(i))
```

---

## Module System

Description: Organized code structure with clear dependencies.

---

### File Organization

Description: Clear structure for maintainability.

* **Rules**
     * One class per file (class name matches filename)
     * Module groups related files in directory
     * Special module.fusion file defines module
     * Subclasses can be nested within class file
     * Modules cannot be nested in other modules

* **Directory Structure**

```
project/
├── Spaceships/
│   ├── module.fusion          // Module definition
│   ├── Spaceship.fusion        // One class
│   ├── Warship.fusion          // One class
│   └── CargoShip.fusion        // One class
├── Weapons/
│   ├── module.fusion
│   ├── Laser.fusion
│   └── Missile.fusion
└── main.fusion
```

---

### Module Definition

Description: Define module in module.fusion file.

```
// Spaceships/module.fusion
module Spaceships

export Spaceship
export Warship
export CargoShip

// Private helper (not exported)
void function validateShipName(string name)
    return name.length > 0
```

---

### Class Files

Description: One class per file with optional nested subclasses.

```
// Spaceships/Spaceship.fusion
class Spaceship
    string name
    float speed
    
    constructor(string name, float speed)
        this.name = name
        this.speed = speed
    
    void function start()
        print("{name} started")
    
    // Nested subclass allowed
    class Engine
        float power
        
        constructor(float power)
            this.power = power
```

---

### Import Syntax

Description: Multiple ways to import modules and classes.

```
// Import entire module
import Spaceships

// Use with module prefix
Spaceship ship = Spaceships.Spaceship("Enterprise", 100.0)

// Import specific class
import Spaceships.Spaceship

// Use without prefix
Spaceship ship = Spaceship("Enterprise", 100.0)

// Import all from module
import Spaceships.*

// Use all exported classes
Spaceship ship = Spaceship("Enterprise", 100.0)
Warship warship = Warship("Destroyer", 150.0, 50)
```

---

### Visibility Control

Description: Control what is accessible from outside module.

```
// module.fusion
module Spaceships

export Spaceship        // Public: can be imported
export Warship          // Public: can be imported

// CargoShip not exported - internal to module only

void function internalHelper()  // Not exported - module-private
    // ...
```

---

## Complete Game Example

Description: Putting it all together in a simple space game using Fusion v2 syntax.

```
// game.fusion - Complete space game example
module SpaceGame

// Vector math structure
struct Vector2
    float x
    float y
    
    constructor(float x, float y)
        this.x = x
        this.y = y
    
    Vector2 operator +(Vector2 other)
        return Vector2(x + other.x, y + other.y)
    
    Vector2 operator *(float scalar)
        return Vector2(x * scalar, y * scalar)

// Base game object interface
interface IGameObject
    property Position: Vector2 { get; set; }
    void function update(float deltaTime)
    void function render()

// Spaceship class
class Spaceship implements IGameObject
    property Position: Vector2 { get; set; }
    property Velocity: Vector2 { get; set; }
    property Health: float { get; set; }
    property Name: string { get; private set; }
    
    private float fuel
    private bool isActive
    
    constructor(string name, Vector2 startPos)
        this.Name = name
        this.Position = startPos
        this.Velocity = Vector2(0, 0)
        this.Health = 100.0
        this.fuel = 100.0
        this.isActive = true
    
    void function accelerate(Vector2 direction, float power)
        if fuel > 0 and isActive
            Velocity = Velocity + (direction * power)
            fuel -= power * 0.1
    
    void function update(float deltaTime)
        if isActive
            Position = Position + (Velocity * deltaTime)
            
            // Apply drag
            Velocity = Velocity * 0.99
            
            // Regenerate fuel slowly
            if fuel < 100
                fuel += deltaTime * 2.0
        end loop
    
    void function render()
        if isActive
            drawSprite("ship", Position.x, Position.y)
            drawHealthBar(Position.x, Position.y - 20, Health)
    
    void function takeDamage(float amount)
        Health -= amount
        if Health <= 0
            Health = 0
            isActive = false
            print("{Name} destroyed!")

// Projectile class
class Projectile implements IGameObject
    property Position: Vector2 { get; set; }
    property Velocity: Vector2 { get; set; }
    property Damage: float { get; private set; }
    
    private float lifetime
    private float maxLifetime = 3.0
    
    constructor(Vector2 startPos, Vector2 velocity, float damage)
        this.Position = startPos
        this.Velocity = velocity
        this.Damage = damage
        this.lifetime = 0
    
    void function update(float deltaTime)
        Position = Position + (Velocity * deltaTime)
        lifetime += deltaTime
    
    void function render()
        if lifetime < maxLifetime
            drawCircle(Position.x, Position.y, 3, Color.Yellow)
    
    property IsExpired: bool
        get
            return lifetime >= maxLifetime

// Game manager class
class GameManager
    private List<Spaceship> ships
    private List<Projectile> projectiles
    private float gameTime
    private bool isRunning
    
    constructor()
        ships = List<Spaceship>()
        projectiles = List<Projectile>()
        gameTime = 0
        isRunning = false
    
    void function initialize()
        // Create player ship
        Spaceship player = Spaceship("Player", Vector2(400, 300))
        ships.append(player)
        
        // Create enemy ships
        for i in range(5)
            Vector2 enemyPos = Vector2(100 + i * 150, 100)
            Spaceship enemy = Spaceship("Enemy-{i}", enemyPos)
            ships.append(enemy)
        end loop
        
        isRunning = true
        print("Game initialized with {ships.Count} ships")
    
    void function update(float deltaTime)
        if not isRunning
            return
        
        gameTime += deltaTime
        
        // Update all ships
        for ship in ships
            ship.update(deltaTime)
        end loop
        
        // Update projectiles
        for projectile in projectiles
            projectile.update(deltaTime)
        end loop
        
        // Remove expired projectiles
        projectiles = projectiles.filter(lambda p: not p.IsExpired)
        
        // Check collisions
        checkCollisions()
        
        // Remove destroyed ships
        ships = ships.filter(lambda s: s.Health > 0)
        
        // Check win/lose conditions
        if ships.Count == 1
            print("Victory! Time: {gameTime} seconds")
            isRunning = false
    
    void function render()
        clearScreen()
        
        for ship in ships
            ship.render()
        end loop
        
        for projectile in projectiles
            projectile.render()
        end loop
        
        drawText("Ships: {ships.Count}", 10, 10)
        drawText("Time: {gameTime}", 10, 30)
    
    void function fireProjectile(Spaceship fromShip, Vector2 direction)
        Projectile projectile = Projectile(
            fromShip.Position,
            direction * 500.0,
            25.0
        )
        projectiles.append(projectile)
    
    private void function checkCollisions()
        for projectile in projectiles
            for ship in ships
                float dx = ship.Position.x - projectile.Position.x
                float dy = ship.Position.y - projectile.Position.y
                float distance = dx * dx + dy * dy
                
                if distance < 400  // 20 pixel radius squared
                    ship.takeDamage(projectile.Damage)
                    projectile.lifetime = projectile.maxLifetime
            end loop
        end loop

// Main game loop
void function main()
    GameManager game = GameManager()
    game.initialize()
    
    float lastTime = getTime()
    
    while game.isRunning
        float currentTime = getTime()
        float deltaTime = currentTime - lastTime
        lastTime = currentTime
        
        // Handle input
        if isKeyPressed(Key.Space)
            Spaceship player = game.ships[0]
            game.fireProjectile(player, Vector2(0, -1))
        
        if isKeyDown(Key.Left)
            game.ships[0].accelerate(Vector2(-1, 0), 10.0)
        
        if isKeyDown(Key.Right)
            game.ships[0].accelerate(Vector2(1, 0), 10.0)
        
        // Update and render
        game.update(deltaTime)
        game.render()
        
        // Cap framerate
        sleep(16)  // ~60 FPS
    end loop
```

---

## Build and Compilation

Description: Flexible compilation options for different targets and use cases.

---

### Compilation Modes

Description: Multiple ways to run and build Fusion code.

* **Script Mode**: Interpreted execution
     * Run directly without compilation
     * Fast development iteration
     * Slower execution
     * Like Python

```
fusion run game.fusion
```

* **Executable Mode**: Native compilation
     * Compile to standalone executable
     * Fast execution
     * Platform-specific binary
     * Like C/Java compiled

```
fusion build game.fusion --output game.exe
```

* **Library Mode**: Shared library
     * Compile to DLL/shared library
     * Reusable across projects
     * Link at runtime or compile time
     * Platform-specific format

```
fusion build engine.fusion --lib --output engine.dll
```

* **JIT Mode**: Just-in-time compilation
     * Compiles during first run
     * Caches compiled code
     * Balance of flexibility and speed
     * Like Java/C#

---

### Build Commands

Description: Command-line build options.

```
// Run as script
fusion run game.fusion

// Compile to executable (debug)
fusion build game.fusion --debug --output game-debug.exe

// Compile to executable (release - optimized)
fusion build game.fusion --release --optimize --output game.exe

// Compile to library
fusion build engine.fusion --lib --release --output engine.dll

// Cross-compile for different platforms
fusion build game.fusion --target linux-x64 --output game-linux
fusion build game.fusion --target windows-x64 --output game.exe
fusion build game.fusion --target wasm --output game.wasm

// Compile with specific optimizations
fusion build game.fusion --optimize speed --output game-fast.exe
fusion build game.fusion --optimize size --output game-small.exe
```

---

### Build Configurations

Description: Common build scenarios.

**Development Build**

* Quick compilation
* Debug symbols included
* No optimizations
* Runtime checks enabled

```
fusion build game.fusion --debug --output game-dev.exe
```

**Release Build**

* Full optimizations
* No debug symbols
* Smaller binary
* Runtime checks disabled

```
fusion build game.fusion --release --optimize --output game.exe
```

**Library Build**

* Creates shared library
* Can be imported by other projects
* Platform-specific format

```
fusion build SpaceshipEngine.fusion --lib --release --output SpaceshipEngine.dll
```

---

### Output Targets

Description: Platform-specific compilation.

Platform | Target | Output Format
---|---|---
Windows | windows-x64 | .exe / .dll
Linux | linux-x64 | (binary) / .so
macOS | macos-arm64 | (binary) / .dylib
Web | wasm | .wasm

---

### Using Libraries

Description: Import compiled libraries in projects.

```
// Link against compiled library
fusion build game.fusion --link engine.dll --output game.exe

// In code
import SpaceshipEngine
Spaceship ship = SpaceshipEngine.createShip("Enterprise")
```

---

## Standard Library

Description: Comprehensive built-in library for common tasks and formats.

---

### Core Collections

* **List<T>**: Dynamic array with resizing
* **Dictionary<K,V>**: Hash map for key-value pairs
* **Set<T>**: Unique elements collection
* **Queue<T>**: FIFO queue
* **Stack<T>**: LIFO stack

---

### Math Library

* **Vector**: 2D, 3D, 4D vector operations
* **Matrix**: Matrix operations and transformations
* **Quaternion**: Rotation calculations
* **Math functions**: sin, cos, tan, sqrt, abs, pow, etc.

---

### File I/O

* **Synchronous**: Read/write operations that block
* **Asynchronous**: Non-blocking I/O with async/await
* **Streams**: Buffered reading and writing

---

### Text File Formats

Description: Built-in support for common text formats.

**Supported Formats**:
* **txt** - Plain text files
* **md** - Markdown documentation
* **JSON** - JavaScript Object Notation
* **XML** - Extensible Markup Language
* **CSV** - Comma-Separated Values
* **YAML** - YAML Ain't Markup Language
* **ini** - Configuration files

**API Example**:
```
import Fusion.IO.JSON

// Read and parse JSON
JSON data, Error err = JSON.readFile("config.json")
if not err
    string name = data.getString("name")
    int value = data.getInt("value")

// Write JSON
JSON output = JSON.create()
output.put("name", "Spaceship")
output.put("speed", 100.0)
err = JSON.writeFile("output.json", output)
```

**Features**:
* Format-specific reader/writer
* Format validation
* Custom format creator framework

---

### Programming Language Support

Description: Built-in compilers, parsers, and lexers for multiple languages.

**Supported Languages**:
* Go, Fusion, Java, C, C++
* VB.NET, JavaScript, HTML, CSS

**Components**:
* **Lexer**: Tokenize source code
* **Parser**: Build Abstract Syntax Tree (AST)
* **Compiler**: Generate executable/bytecode
* **Interpreter**: Execute code directly
* **Custom Language Creator**: Define new language syntax

**API Example**:
```
import Fusion.Compiler

// Compile Fusion code
Compiler fusionCompiler = Compiler.create(Language.FUSION)
Program program, Error err = fusionCompiler.compile("source.fusion")
if not err
    program.execute()

// Parse Java code to AST
Parser javaParser = Parser.create(Language.JAVA)
AST ast, Error err = javaParser.parse(javaCode)
```

---

### Image Formats

Description: Read, write, and manipulate common image formats.

**Supported Formats**:
* BMP - Bitmap
* JPEG/JPG - Joint Photographic Experts Group
* GIF - Graphics Interchange Format
* PNG - Portable Network Graphics

**API Example**:
```
import Fusion.Graphics.Image

// Load image
Image img, Error err = Image.load("photo.jpg")
if not err
    // Edit image
    img.resize(800, 600)
    img.rotate(90)
    img.setPixel(10, 10, Color.RED)
    
    // Save in different format
    err = img.save("output.png", ImageFormat.PNG)
```

**Features**:
* Pixel-level access
* Image transformations
* Format conversion
* Custom format support

---

### Advanced Binary Formats

Description: Support for complex document and archive formats (see fusionlib.Data module).

**Supported Formats**:
* **DOC/DOCX** - Microsoft Word
* **XLS/XLSX** - Microsoft Excel
* **PDF** - Portable Document Format
* **ZIP** - Compressed archives

---

## Fusion Standard Library (fusionlib)

Description: Complete standard library with 15 modules for all common tasks.

**Module Overview**:

Module | Purpose
---|---
Core | Essential types, always needed
Math | Mathematical operations and geometry
Collections | Data structures (List, Dict, Set, etc.)
Threading | Thread management and synchronization
IO | File and stream operations
Net | Network communication (TCP, HTTP, WebSocket)
Lang | Multi-language compilation (10 languages)
Languages | Internationalization (i18n)
System | System operations, DLL loading, processes
Reflection | Runtime type inspection
Test | Unit testing and benchmarking
Diagnostics | Profiling and logging
Data | Text file formats (CSV, XML, YAML)
GUI | User interface (HTML5-compliant)
Graphics | Advanced rendering (2D/3D, games)

See fusion_specs.md for complete API documentation of each module.

---

## Callbacks and Events

Description: Function pointers and event-driven programming.

**Function Types**:
```
// Define callback type
type Callback = void function(int result)
type EventHandler = void function(Object sender, EventArgs args)

// Use callback
void function processAsync(int data, Callback onComplete)
    int result = data * 2
    onComplete(result)

// Lambda callback
processAsync(42, lambda r: print("Result: {r}"))

// Events
class Button
    Event<void function(Button)> onClick
    
    void function click()
        onClick.invoke(this)

Button btn = Button()
btn.onClick += lambda b: print("Clicked!")
```

---

## External Interoperability

Description: Integration with external code and systems.

---

### DLL Loading

```
import Fusion.System.DllLoader

DLL lib = DLL.load("mylib.dll")
type AddFunc = int function(int, int)
AddFunc add = lib.getFunction<AddFunc>("add")
int result = add(10, 20)
lib.unload()
```

---

### External Processes

```
import Fusion.System.Process

Process proc = Process.start("python", ["script.py"])
string output = proc.readOutput()
int exitCode = proc.exitCode
```

---

### Assembly Language

```
@Unsafe
int function fastAdd(int a, int b)
    int result
    asm
        mov eax, [a]
        add eax, [b]
        mov [result], eax
    return result
```

---

### External Compilers

```
import Fusion.Lang.Compiler

Compiler msvc = Compiler.loadExternal("fusion-msvc-x64.dll")
msvc.setOptimizationLevel(3)
CompileResult result = msvc.compile("code.fusion")
```

---

## Auto-Documentation

Description: Generate documentation from source comments.

**Documentation Format**:
```
/**
 * @title Spaceship Class
 * @description Main spaceship entity
 * @category Game/Entities
 * @example
 *   Spaceship ship = Spaceship("Enterprise", 100.0)
 */
class Spaceship
```

**Generate**:
```bash
fusion doc generate --output ./wiki
```

---

**Word Documents**:
```
import Fusion.Documents

Document doc, Error err = Document.load("report.docx")
if not err
    string text = doc.getText()
    doc.appendText("New content")
    doc.save("modified.docx")
```

**Excel Spreadsheets**:
```
import Fusion.Spreadsheet

Workbook wb, Error err = Workbook.load("data.xlsx")
Sheet sheet = wb.getSheet("Sheet1")
string value = sheet.getCell("A1").getValue()
sheet.setCell("B1", "New Value")
wb.save()
```

**PDF Documents**:
```
import Fusion.PDF

PDF pdf = PDF.create()
pdf.addPage()
pdf.drawText(100, 700, "Hello PDF!")
pdf.save("output.pdf")
```

**ZIP Archives**:
```
import Fusion.Archive

ZIP zip = ZIP.create("archive.zip")
zip.addFile("file1.txt")
zip.addFile("file2.txt")
zip.close()
```

---

### Custom Format Creator

Description: Framework for defining new file formats.

```
import Fusion.Format

// Define custom format
FormatDefinition myFormat = FormatDefinition.create("myformat")
myFormat.setMagicBytes([0x4D, 0x59, 0x46, 0x4D])
myFormat.defineField("header", FieldType.STRING, 32)
myFormat.defineField("version", FieldType.INT32)

// Create reader/writer
FormatReader reader = FormatReader.create(myFormat)
FormatWriter writer = FormatWriter.create(myFormat)
```

---

### Localization Support

Description: Multi-language application support.

**Supported Languages**: English, Japanese, Spanish, French, German, Chinese, and more

**API Example**:
```
import Fusion.Localization

// Set current language
Locale.setCurrent("ja-JP")

// Get translated strings
string greeting = Locale.getString("greeting")  // "こんにちは"

// Formatted strings
string message = Locale.format("welcome_user", userName)
```

---

### Networking

* **HTTP**: Client and server implementations
* **WebSocket**: Real-time bidirectional communication
* **TCP/UDP**: Low-level socket programming

---

### Graphics and Audio

* **2D Graphics**: Drawing primitives, sprites, textures
* **3D Graphics**: Rendering, lighting, shaders
* **Audio**: Sound playback, synthesis, effects

---

### Threading and Concurrency

* **Task Parallel Library**: High-level task management
* **Thread Pools**: Efficient worker thread management
* **Channels**: Message passing between threads
* **Async/Await**: Simplified asynchronous programming

---

### Date and Time

* **DateTime**: Date and time manipulation
* **TimeSpan**: Duration calculations
* **Calendar**: Calendar-specific operations
* **Time zones**: Timezone conversions

---

### Regular Expressions

* **Pattern matching**: Powerful text search and replace
* **Validation**: Input validation with regex
* **Parsing**: Extract data from text

---

## Reserved Words and Operators

Description: Keywords and symbols reserved by the Fusion language.

---

## Reserved Words and Operators

Description: Complete list of language keywords and operators.

---

### Reserved Keywords

Description: Words that cannot be used as identifiers.

**Control Flow**:
* `if`, `elif`, `else`
* `match`, `case`
* `for`, `while`, `do`
* `break`, `continue`
* `return`
* `end` (end loop, end function, etc.)

**Type Declarations**:
* `class`, `struct`, `interface`, `enum`
* `property`
* `var`, `const`
* `static`

**Access Modifiers**:
* `public`, `private`, `protected`, `internal`

**Memory & Pointers**:
* `unsafe`
* `allocate`, `deallocate`
* `Unique`, `Shared`, `Weak`

**Functions & Methods**:
* `function`
* `constructor`
* `lambda`
* `async`, `await`

**Modules**:
* `module`
* `import`, `export`

**Operators & Logic**:
* `and`, `or`, `not`
* `is`, `in`
* `where`

**Threading & Concurrency**:
* `thread`, `channel`
* `goroutine`
* `lock`, `unlock`
* `try` (try-with-resources)

**Error Handling**:
* `try`, `catch`, `finally`
* `throw`, `Error`

**Literals**:
* `true`, `false`
* `null`, `none`

**Special**:
* `this`, `super`
* `goto` (reserved but not used, except in unsafe embedded mode)

**Annotations & Directives**:
* `#Region`, `#End Region`
* `#[attribute]` (for annotations like `#[no_loop_protection]`)

---

### Operators

Description: Symbols used for operations.

---

#### Arithmetic Operators

Operator | Description | Example
---|---|---
`+` | Addition | `a + b`
`-` | Subtraction | `a - b`
`*` | Multiplication | `a * b`
`/` | Division | `a / b`
`%` | Modulo | `a % b`
`**` | Exponentiation | `a ** 2` (a squared)

---

#### Comparison Operators

Operator | Description | Example
---|---|---
`==` | Equal to | `a == b`
`!=` | Not equal to | `a != b`
`<>` | Not equal to (alternative) | `a <> b`
`<` | Less than | `a < b`
`>` | Greater than | `a > b`
`<=` | Less than or equal to | `a <= b`
`>=` | Greater than or equal to | `a >= b`

---

#### Logical Operators

Operator | Description | Example
---|---|---
`and` | Logical AND | `a and b`
`or` | Logical OR | `a or b`
`not` | Logical NOT | `not a`
`&&` | Alternative AND | `a && b`
`||` | Alternative OR | `a || b`
`!` | Alternative NOT | `!a`

---

#### Bitwise Operators

Operator | Description | Example
---|---|---
`&` | Bitwise AND | `a & b`
`|` | Bitwise OR | `a | b`
`^` | Bitwise XOR | `a ^ b`
`~` | Bitwise NOT | `~a`
`<<` | Left shift | `a << 2`
`>>` | Right shift | `a >> 2`

---

#### Assignment Operators

Operator | Description | Example
---|---|---
`=` | Assignment | `a = 10`
`+=` | Add and assign | `a += 5`
`-=` | Subtract and assign | `a -= 5`
`*=` | Multiply and assign | `a *= 2`
`/=` | Divide and assign | `a /= 2`
`%=` | Modulo and assign | `a %= 3`

---

#### Special Operators

Operator | Description | Example
---|---|---
`.` | Member access | `object.property`
`?.` | Safe navigation | `object?.property`
`??` | Null coalescing | `value ?? default`
`[]` | Array/index access | `array[0]`
`?[]` | Safe array access | `array?[0]`
`()` | Function call / grouping | `function(args)`
`...` | Spread/variadic/range | `1...10`, `int... args`
`::` | Scope resolution | `Module::Class`
`->` | (Not used in Fusion, replaced by return-type-first)

---

### Operator Precedence

Description: Order of operations from highest to lowest priority.

Priority | Operators | Associativity
---|---|---
1 | `()`, `[]`, `.`, `?.` | Left-to-right
2 | `**` | Right-to-left
3 | `~`, `!`, `not`, unary `-`, unary `+` | Right-to-left
4 | `*`, `/`, `%` | Left-to-right
5 | `+`, `-` | Left-to-right
6 | `<<`, `>>` | Left-to-right
7 | `<`, `<=`, `>`, `>=` | Left-to-right
8 | `==`, `!=`, `<>` | Left-to-right
9 | `&` | Left-to-right
10 | `^` | Left-to-right
11 | `|` | Left-to-right
12 | `and`, `&&` | Left-to-right
13 | `or`, `||` | Left-to-right
14 | `??` | Left-to-right
15 | `=`, `+=`, `-=`, `*=`, `/=`, `%=` | Right-to-left

**Use parentheses for clarity**: When in doubt, use `()` to make order explicit.

---

## Language Features Summary

Description: Comprehensive overview of Fusion's capabilities and design decisions.

---

### Syntax Features

* **Function Declaration**: `<returnType> function name(<type> param = defaultValue)`
* **Variable Declaration**: `type name = value` or `var name = value`
* **Constructor**: `constructor(type param)` - explicit keyword
* **Loop Endings**: `end loop` with optional safety checks
* **No Semicolons**: Line breaks end statements
* **Flexible Blocks**: Indentation-based or braces (user preference)
* **Named Parameters**: `function(param2 = value, param1 = value)`
* **Default Parameters**: Optional parameter values
* **Enums**: Three syntax styles (braces, indentation, single-line)
* **Comments**: Both `//` and `'` supported, `/* */` for multi-line
* **Regions**: `#Region` / `#End Region` for code organization
* **Comparison Operators**: Both `!=` and `<>` for not-equal
* **Spread Operator**: `...` for variadic, range, and array spread

---

### Enumerations

* **Multiple Syntaxes**: Braces, indentation, or single-line
* **Custom Values**: Integer values for enum constants
* **Type Safety**: Cannot assign int directly to enum
* **Built-in Methods**: `toString()`, `values()`, `fromString()`
* **Usage**: In switch/match statements, comparisons

---

### The `...` Operator

* **Range in Loops**: `for i in 1...100`
* **Variadic Functions**: `int function sum(int... numbers)`
* **Array Spread**: `[...arr1, ...arr2]`
* **Rest Parameters**: `function log(string level, string... messages)`
* **Can Be Disabled**: In strict mode if needed

---

### Type System

* **Value Types**: Never null (int, float, bool, char, struct)
* **Reference Types**: Can be null (objects, string)
* **No Nullable Value Types**: Syntax like `int?` does not exist
* **Explicit Null Checks**: `object?.null` or `object is null`
* **String Implementation**: Immutable, copy-on-write, string pool
* **Type Casting**: Implicit widening, explicit narrowing
* **Default Values**: All types have defaults (0, false, "", null)
* **Enums**: Type-safe enumeration values

---

### Static Members and Constants

* **Static Methods**: Belong to class, not instance
* **Static Fields**: Shared across all instances
* **Constants**: Automatically static (no instance constants)
* **Access**: Via `ClassName.memberName`
* **Visibility**: Can be public or private

---

### Array Safe Navigation

* **Safe Access**: `array?[0]` returns null if array is null
* **Safe Methods**: `array?.sum()`, `array?.map()`
* **Chaining**: `array?.filter()?.max()`
* **Manual Handling**: Programmer must handle null afterward
* **Optional Use**: Can use `?.` or not (user choice)

---

### Error Handling

* **Multiple Return Values**: `result, err = function()`
* **Optional Error Capture**: `result = function()` (error bubbles up)
* **Error Object**: Built-in with message, code, stack trace
* **Traditional Exceptions**: Available for unexpected errors
* **When to Use**: Multiple returns for expected, exceptions for unexpected

---

### Memory Management

* **Tier 1**: Automatic garbage collection (default)
* **Tier 2**: Smart pointers (Unique, Shared, Weak) for performance
* **Tier 3**: Raw pointers (unsafe mode, embedded systems only)
* **Strategy**: Start with GC, optimize with smart pointers if needed

---

### Null Safety

* **Value Types**: Cannot be null, always have value
* **Objects**: Must check with `?.null` or `is null`
* **Safe Navigation**: `object?.property` returns none if null
* **Strict Mode**: Compiler enforces null checks
* **String Safety**: `string?.length` returns 0 if null

---

### Autoboxing

* **Automatic Conversion**: Primitives become objects when needed
* **Method Calls**: `(42).toString()`, `(3.14).round(2)`
* **Autobox Classes**: Int, Long, Float, Double, Boolean, Char, Byte
* **Performance**: Compiler optimizes unnecessary boxing

---

### Properties

* **Auto-Properties**: `property Name: type { get; set; }`
* **Computed Properties**: Custom get/set with validation
* **Indexed Properties**: `property Items[int index]: type`
* **Indexed-Only**: Prevent array replacement, allow element access
* **Multi-Dimensional**: `property Cell[int x, int y]: type`

---

### Structures

* **Value Semantics**: Copied, not referenced
* **Allowed Types**: Primitives, string, fixed arrays only
* **Not Allowed**: Objects, dynamic collections
* **Use Case**: Pure data containers for performance

---

### Threading and Concurrency

* **Message Passing**: Channels for safe communication (Go-style)
* **Shared Memory**: Traditional locks when needed
* **Async/Await**: Built-in for I/O operations
* **Thread Interrupts**: Cooperative multitasking via loop checks
* **Philosophy**: "Share memory by communicating"

---

### Loops

* **Explicit Endings**: `end loop` marker
* **Safety Checks**: Manual, periodic, iteration limit, interrupt handling
* **Check Types**: `end loop with {count} check ...`
* **Automatic Protection**: Compiler adds infinite loop prevention
* **Resource Monitoring**: Adapts to system RAM/CPU
* **Thread Safety**: Interrupt handling built-in
* **Range Operator**: `for i in 1...100` with optional step
* **Configurable**: Per-project or per-loop settings

---

### Standard Library

* **File Formats**: txt, md, JSON, XML, CSV, YAML, ini
* **Programming Languages**: Compilers for Go, Fusion, Java, C, C++, VB.NET, JS, HTML, CSS
* **Image Formats**: BMP, JPEG, GIF, PNG readers/writers
* **Binary Formats**: DOC, Excel, PDF, ZIP support
* **Custom Formats**: Framework for defining new formats
* **Localization**: Multi-language support (English, Japanese, etc.)
* **Collections**: List, Dictionary, Set, Queue, Stack
* **Math**: Vector, Matrix, Quaternion libraries
* **Networking**: HTTP, WebSocket, TCP/UDP
* **Graphics**: 2D and 3D rendering primitives
* **Audio**: Sound playback and synthesis

---

### Modules

* **Organization**: One class per file
* **Module Definition**: Special module.fusion file
* **Import Syntax**: `import Module` or `import Module.Class`
* **Visibility**: Export control for public/private
* **Nested Classes**: Allowed within class file

---

### Compilation

* **Script Mode**: Run directly without compilation
* **Executable**: Native binary compilation
* **Library**: DLL/shared library for reuse
* **JIT Mode**: Just-in-time compilation
* **Cross-Platform**: Linux, Windows, macOS, WebAssembly

---

### From Parent Languages

* **From C**: Performance, structs, memory control, operators
* **From Java**: Strong typing, interfaces, generics, OOP structure
* **From Python**: Simple syntax, indentation, easy to read
* **From VB.NET**: Readable keywords, properties, explicit intent
* **From Go**: Message passing, channels, multiple returns, goroutines

---

### Unique to Fusion

* **Return-Type-First**: Clear function signatures
* **Value/Reference Distinction**: Explicit null safety
* **Flexible Block Syntax**: Indentation or braces (user preference)
* **Three Enum Syntaxes**: Braces, indentation, or single-line
* **Dual Comment Styles**: Both `//` and `'` supported
* **Loop Safety Checks**: Multiple check types with automatic protection
* **Indexed Properties**: Enhanced array access
* **Error Bubbling**: Optional error capture with multiple returns
* **Three-Tier Memory**: GC, smart pointers, or raw
* **Script or Compile**: Choose execution mode
* **`...` Operator**: Multi-purpose (range, spread, variadic)
* **`<>` Comparison**: Alternative to `!=` for not-equal
* **Automatic Locking**: Try-with-resources prevents deadlocks
* **Weak Pointers Discouraged**: Error in strict mode
* **Constants Auto-Static**: No instance constants
* **Comprehensive Standard Library**: Built-in support for 20+ file formats
* **Programming Language Support**: Built-in compilers for 9 languages
* **IDE Integration**: Threading visualization, code regions

